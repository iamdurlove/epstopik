"use strict"

$(document).ready(function () {
    $('#score').attr('value', per_score);
    progress_bar();
});
